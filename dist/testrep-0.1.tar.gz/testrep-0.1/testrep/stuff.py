def test_success():
	assert True

def add_and_del(startnum, addnum, delnum):
	return startnum + addnum - delnum
