from distutils.core import setup
setup(
	name = 'mypackage',
	packages = ['mypackage'],
	version = '0.0',
	description = 'this is something, I dont know',
	author = 'Ernesto Perez',
	author_email = 'ErnestoGPerez91@yahoo.com',
	url = 'https://github.com/ErnestoGP/testrep',
	download_url = 'https://github.com/ErnestoGP/testrep/archive/0.1.tar.gz',
	keywords = ['test', 'thing', 'Idunno'],
	classifiers = [],
)
