from distutils.core import setup
setup(
	name = 'testrep',
	packages = ['testrep'],
	version = '0.0',
	description = 'this is a test upload with simple commands to see if I can install a package with the pip install command',
	author = 'Ernesto Perez',
	author_email = 'ErnestoGPerez91@yahoo.com',
	url = 'https://github.com/ErnestoGP/testrep',
	download_url = 'https://github.com/ErnestoGP/testrep/archive/0.1.tar.gz',
	keywords = ['test', 'thing', 'Idunno'],
	classifiers = [],
)
